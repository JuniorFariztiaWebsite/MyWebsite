function showImage() {
    var imageContainer = document.getElementById('imageContainer');
    imageContainer.classList.add('visible');
}
